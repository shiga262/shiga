﻿using System;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace курсачч
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
          
        }
        static string connectionString = "Data Source=ZZZ\\SQLEXPRESS;Initial Catalog=курсачч;Integrated Security=True";
        public static bool addUser(Пользователь user1)
        {
            
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    string query = "INSERT INTO Пользователь (Пароль, Имя, Предмет, Роль) VALUES (@Пароль, @Имя, @Предмет, @Роль)";

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@Пароль", user1.Пароль);
                        command.Parameters.AddWithValue("@Имя", user1.Имя);
                        command.Parameters.AddWithValue("@Предмет", user1.Предмет);
                        command.Parameters.AddWithValue("@Роль", user1.Роль);


                        connection.Open();
                        int result = command.ExecuteNonQuery();

                        if (result < 0)
                            return false;
                        return true;
                    }
                }
            
            
        }
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Пользователь newUser = new Пользователь(tevName.Te);
                //Пользователь user1 = new Пользователь();
                //user1.Пароль = tevName.Password;
                //user1.Имя = tbName.Text;
                //user1.Предмет = SubjectComboBox.SelectedValue.ToString();
                //user1.Роль = RoleComboBox.SelectedValue.ToString();
                //addUser(user1);

                Window1 a = new Window1();
                a.Show();
                this.Close();
            }
            catch (Exception ex)
            { MessageBox.Show(ex.ToString()); }
        }
        private void RoleComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            int d=RoleComboBox.SelectedIndex;
            if (d ==1)
            {
                
            }
            else
            {
                
            }
        }

    }


}
