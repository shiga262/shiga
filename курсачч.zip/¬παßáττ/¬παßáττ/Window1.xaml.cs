﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace курсачч
{
    /// <summary>
    /// Логика взаимодействия для Window1.xaml
    /// </summary>
    public partial class Window1 : Window
    {
        // Словарь для связи названий групп с их ID
        private Dictionary<string, int> groupIds = new Dictionary<string, int>
        {
            { "Группа т-196", 1 },
            { "Группа т-197", 2 },
            { "Группа т-198", 3 }
            // Добавьте здесь другие группы по мере необходимости
        };

        public Window1()
        {
            InitializeComponent();
            group.Visibility = Visibility.Visible;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string selectedRole = (role.SelectedItem as ComboBoxItem)?.Content.ToString();
            string username = name.Text;
            string password = pass.Password;

            if (selectedRole == "Учитель")
            {
                MessageBox.Show("Вы вошли как учитель");
                Window2 a2 = new Window2(); // Открываем окно для учителя
                a2.Show();
                this.Close();
            }
            else if (selectedRole == "Ученик")
            {
                if (group.SelectedItem != null) // Проверка, что в ComboBox выбрана какая-то группа
                {
                    string groupName = (group.SelectedItem as ComboBoxItem)?.Content.ToString(); // Получение выбранного значения из ComboBox

                    if (groupName != "" && groupIds.ContainsKey(groupName))
                    {
                        int groupId = groupIds[groupName]; // Получение ID группы из словаря
                        Window3 a = new Window3(groupId, "Student"); // Использование ID группы при создании нового экземпляра Window3
                        a.Show();
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Выбранная группа не найдена в словаре.");
                    }
                }
                else
                {
                    MessageBox.Show("Пожалуйста, выберите группу из списка."); // Сообщение пользователю, если ничего не выбрано в ComboBox
                }
            }
            else
            {
                MessageBox.Show("Пожалуйста, выберите роль из списка."); // Сообщение пользователю, если роль не выбрана
            }
        }

        private void group_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            // Получаем выбранную группу
            string selectedGroup = (group.SelectedItem as ComboBoxItem)?.Content.ToString();

            if (selectedGroup != null && groupIds.ContainsKey(selectedGroup))
            {
                int groupId = groupIds[selectedGroup]; // Получаем ID группы из словаря
                MessageBox.Show($"Выбрана группа {selectedGroup} с ID {groupId}.");
            }
            else
            {
                MessageBox.Show("Выбранная группа не найдена в словаре.");
            }
        }

        private void role_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var selectedRole = (role.SelectedItem as ComboBoxItem)?.Content.ToString();
            if (selectedRole == "Учитель")
            {
                group.Visibility = Visibility.Collapsed;
            }
            else
            {
                group.Visibility = Visibility.Visible;
            }
        }
    }
}