﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace курсачч
{
    /// <summary>
    /// Логика взаимодействия для Window4.xaml
    /// </summary>
    public partial class Window4 : Window
    {
        private string userRole;

        public Window4(bool isTeacher)
        {
            InitializeComponent();
            SetCheckBoxesState(isTeacher);
        }

        public Window4(string userRole)
        {
            this.userRole = userRole;
        }

        private void SetCheckBoxesState(bool isEnabled)
        {
            VadimCheckBox1.IsEnabled = isEnabled;
            VadimCheckBox2.IsEnabled = isEnabled;
            VadimCheckBox3.IsEnabled = isEnabled;
            VadimCheckBox4.IsEnabled = isEnabled;
            VadimCheckBox5.IsEnabled = isEnabled;
            VadimCheckBox6.IsEnabled = isEnabled;
            VadimCheckBox7.IsEnabled = isEnabled;
            VadimCheckBox8.IsEnabled = isEnabled;

            VasiliyCheckBox1.IsEnabled = isEnabled;
            VasiliyCheckBox2.IsEnabled = isEnabled;
            VasiliyCheckBox3.IsEnabled = isEnabled;
            VasiliyCheckBox4.IsEnabled = isEnabled;
            VasiliyCheckBox5.IsEnabled = isEnabled;
            VasiliyCheckBox6.IsEnabled = isEnabled;
            VasiliyCheckBox7.IsEnabled = isEnabled;
            VasiliyCheckBox8.IsEnabled = isEnabled;

            VasyaCheckBox1.IsEnabled = isEnabled;
            VasyaCheckBox2.IsEnabled = isEnabled;
            VasyaCheckBox3.IsEnabled = isEnabled;
            VasyaCheckBox4.IsEnabled = isEnabled;
            VasyaCheckBox5.IsEnabled = isEnabled;
            VasyaCheckBox6.IsEnabled = isEnabled;
            VasyaCheckBox7.IsEnabled = isEnabled;
            VasyaCheckBox8.IsEnabled = isEnabled;

            GoshaCheckBox1.IsEnabled = isEnabled;
            GoshaCheckBox2.IsEnabled = isEnabled;
            GoshaCheckBox3.IsEnabled = isEnabled;
            GoshaCheckBox4.IsEnabled = isEnabled;
            GoshaCheckBox5.IsEnabled = isEnabled;
            GoshaCheckBox6.IsEnabled = isEnabled;
            GoshaCheckBox7.IsEnabled = isEnabled;
            GoshaCheckBox8.IsEnabled = isEnabled;

            PavelCheckBox1.IsEnabled = isEnabled;
            PavelCheckBox2.IsEnabled = isEnabled;
            PavelCheckBox3.IsEnabled = isEnabled;
            PavelCheckBox4.IsEnabled = isEnabled;
            PavelCheckBox5.IsEnabled = isEnabled;
            PavelCheckBox6.IsEnabled = isEnabled;
            PavelCheckBox7.IsEnabled = isEnabled;
            PavelCheckBox8.IsEnabled = isEnabled;
        }
    }
}