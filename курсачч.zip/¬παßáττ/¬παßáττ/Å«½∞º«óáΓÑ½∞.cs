﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace курсачч
{
    public class Пользователь
    {
        public int Пользовательid { get; set; }
        public string Пароль { get; set; }
        public string Имя { get; set; }
        public string Предмет { get; set; }
        public string Роль { get; set; }

        // Конструктор
        public Пользователь(int пользовательid, string пароль, string имя, string фамилия, string предмет, string роль)
        {
            Пользовательid = пользовательid;
            Пароль = пароль;
            Имя = имя;
            Предмет = предмет;
            Роль = роль;
        }
        public Пользователь(string id)
        { }
    }
}
