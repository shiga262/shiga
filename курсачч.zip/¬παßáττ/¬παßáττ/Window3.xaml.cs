﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace курсачч
{
    public partial class Window3 : Window
    {
        private int groupId;
        private string userRole;

        public Window3(string groupName)
        {
            InitializeComponent();
            LoadData(groupName);
        }

        public Window3(int groupId, string userRole)
        {
            InitializeComponent();
            this.groupId = groupId;
            this.userRole = userRole;
            LoadData(groupId);
        }

        public void LoadData(int id)
        {
            try
            {
                string connectionString = "Data Source=ZZZ\\SQLEXPRESS;Initial Catalog=курсачч;Integrated Security=True";
                string sql = $"SELECT * FROM Студенты INNER JOIN Группы ON Студенты.id_группы = Группы.id_группы WHERE Группы.id_группы = '{id}'";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(sql, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        var student = new Student
                        {
                            Id = reader[0].ToString(),
                            Name = reader[1].ToString(),
                        };

                        for (int i = 2; i <= 31; i++)
                        {
                            student.Dates.Add(reader[i].ToString());
                        }

                        dgStudents.Items.Add(student);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        public void LoadData(string groupName)
        {
            try
            {
                string connectionString = "Data Source=ZZZ\\SQLEXPRESS;Initial Catalog=курсачч;Integrated Security=True";
                string sql = $"SELECT * FROM Студенты INNER JOIN Группы ON Студенты.id_группы = Группы.id_группы WHERE Группы.Название = '{groupName}'";
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(sql, connection);
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        var student = new Student
                        {
                            Id = reader[0].ToString(),
                            Name = reader[1].ToString(),
                        };

                        for (int i = 2; i <= 31; i++)
                        {
                            student.Dates.Add(reader[i].ToString());
                        }

                        dgStudents.Items.Add(student);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void OpenWindow4_Click(object sender, RoutedEventArgs e)
        {
            Window4 window4 = new Window4(userRole);
            window4.Show();
            this.Close();
        }
    }
}