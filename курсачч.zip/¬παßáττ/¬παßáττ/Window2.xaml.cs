﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data.SqlClient;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace курсачч
{
    /// <summary>
    /// Логика взаимодействия для Window2.xaml
    /// </summary>
    public partial class Window2 : Window
    {
        public ObservableCollection<string> Groups { get; set; }

        public Window2()
        {
            try
            {
                InitializeComponent();
                LoadData();
            }
            catch (Exception ex) { MessageBox.Show(ex.ToString()); }
        }

        public void LoadData()
        {
            string connectionString = "Data Source=ZZZ\\SQLEXPRESS;Initial Catalog=курсачч;Integrated Security=True";
            string sql = "SELECT Группы.Название, COUNT(Студенты.id_студента) as Количество_студентов FROM Группы INNER JOIN Студенты ON Группы.id_группы = Студенты.id_группы GROUP BY Группы.Название ORDER BY Группы.Название";
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(sql, connection);
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    lvGroups.Items.Add(new { Name = reader[0].ToString(), StudentCount = reader[1].ToString() });
                }
            }
        }

        private void lvGroups_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lvGroups.SelectedItem != null)
            {
                var selectedGroup = (dynamic)lvGroups.SelectedItem;
                Window3 window3 = new Window3(selectedGroup.Name, "Teacher"); // Передаем роль при создании экземпляра Window3
                window3.Show();
                this.Close();
            }
        }
    }
}
