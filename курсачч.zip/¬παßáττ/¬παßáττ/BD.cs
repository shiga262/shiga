﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace курсачч
{
    public class BD
    {
        static string connectionString = "Data Source=ZZZ\\SQLEXPRESS;Initial Catalog=курсачч;Integrated Security=True";
        public static bool addUser(string имя, string фамилия, string роль, string логин, string пароль)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Пользователь (Имя, Фамилия, Роль, Логин, Пароль) VALUES (@Имя, @Фамилия, @Роль, @Логин, @Пароль)";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Имя", имя);
                    command.Parameters.AddWithValue("@Фамилия", фамилия);
                    command.Parameters.AddWithValue("@Роль", роль);
                    command.Parameters.AddWithValue("@Логин", логин);
                    command.Parameters.AddWithValue("@Пароль", пароль);

                    connection.Open();
                    int result = command.ExecuteNonQuery();

                    if (result < 0)
                        return false;
                    return true;
                }
            }
        }
        public static int authenticateUser(string логин, string пароль)
        {
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                string query = "SELECT Роль FROM Пользователь WHERE Имя = @Имя AND Пароль = @Пароль";

                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Имя", логин);
                    command.Parameters.AddWithValue("@Пароль", пароль);

                    connection.Open();
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            string роль = reader["Роль"].ToString();
                            if (роль == "Ученик")
                            {
                                return 1;
                            }
                            else if (роль == "Учитель")
                            {
                                return 2;
                            }
                        }
                    }
                }
            }
            return 0; 
        }


    }
}