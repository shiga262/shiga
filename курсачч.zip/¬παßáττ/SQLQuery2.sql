﻿CREATE TABLE [dbo].[Группы] (
    [id_группы] INT  IDENTITY (1, 1) PRIMARY KEY NOT NULL,
    [Название]       NVARCHAR (50) NULL,
    [Количество]         INT           NULL
);
DROP TABLE [dbo].[Группы]
DROP TABLE [dbo].[Студенты]
CREATE TABLE [dbo].[Студенты] (
    [id] INT  IDENTITY (1, 1) NOT NULL,
    [Имя ученика]       NVARCHAR (50) NULL,
    [day1]         INT           NULL,
    [day2]         INT           NULL,
    [day3]         INT           NULL,
    [day4]         INT           NULL,
    [day5]         INT           NULL,
    [day6]         INT           NULL,
    [day7]         INT           NULL,
    [day8]         INT           NULL,
    [day9]         INT           NULL,
    [day10]         INT           NULL,
    [day11]         INT           NULL,
    [day12]         INT           NULL,
    [day13]         INT           NULL,
    [day14]         INT           NULL,
    [day15]         INT           NULL,
    [day16]         INT           NULL,
    [day17]         INT           NULL,
    [day18]         INT           NULL,
    [day19]         INT           NULL,
    [day20]         INT           NULL,
    [day21]         INT           NULL,
    [day22]         INT           NULL,
    [day23]         INT           NULL,
    [day24]         INT           NULL,
    [day25]         INT           NULL,
    [day26]         INT           NULL,
    [day27]         INT           NULL,
    [day28]         INT           NULL,
    [day29]         INT           NULL,
    [day30]         INT           NULL,
    [day31]         INT           NULL,
    id_группы INT,
    FOREIGN KEY (id_группы) REFERENCES Группы(id_группы)
);